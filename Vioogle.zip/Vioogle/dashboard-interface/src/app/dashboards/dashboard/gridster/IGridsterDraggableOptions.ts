export interface IGridsterDraggableOptions {
	handlerClass?: string;
	zIndex?: number;
	scroll?: boolean;
	containment?: string;
}
