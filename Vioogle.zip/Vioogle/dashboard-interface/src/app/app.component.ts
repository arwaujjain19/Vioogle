import { Component, ViewChild } from '@angular/core';

import { VisualizationsComponent } from './visualizations/visualizations.component';

import { DataService } from './data.service';


@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})

export class AppComponent {
		url;
		format;
		onSelectFile(event) {
		  const file = event.target.files && event.target.files[0];
		  if (file) {
			var reader = new FileReader();
			reader.readAsDataURL(file);
			if(file.type.indexOf('image')> -1){
			  this.format = 'image';
			} else if(file.type.indexOf('video')> -1){
			  this.format = 'video';
			}
			reader.onload = (event) => {
			  this.url = (<FileReader>event.target).result;
			}
		  }
		}
	  
	title: string = '';

	constructor(
		private dataService: DataService
	) { }

	ngOnInit(): void {
		this.getTitle();
	}

	getTitle(): void {
		this.title = this.dataService.getTitle();
	}
}


